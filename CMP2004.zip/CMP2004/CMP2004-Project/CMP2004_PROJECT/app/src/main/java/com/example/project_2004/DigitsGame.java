package com.example.project_2004;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DigitsGame extends AppCompatActivity {

    private int [] numbersShown = {9,5,2,15,34,12,67};

    TextView digitsShown,numbersLeft;
    Button next;

    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_digits_game);

        numbersLeft = findViewById(R.id.textViewNumbersLeft);
        digitsShown = findViewById(R.id.textViewDigitsShown);
        next = findViewById(R.id.buttonNext);



        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(counter > 6){
                    Intent i = new Intent(DigitsGame.this,DigitsGameQuiz.class);
                    startActivity(i);
                }

                numbersLeft.setText(""+(6-counter));
                digitsShown.setText("" + numbersShown[counter]);
                counter++;
            }
        });

    }

}