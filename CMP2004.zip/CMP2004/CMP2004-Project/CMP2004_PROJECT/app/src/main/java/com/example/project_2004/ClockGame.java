package com.example.project_2004;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;


public class ClockGame extends AppCompatActivity {

    private List<Integer> imgList = Arrays.asList(
            R.drawable.clock_8_30_image,
            R.drawable.clock_2_30_image,
            R.drawable.clock_18_image,
            R.drawable.clock_10_45_image,
            R.drawable.clock_12_30_image,
            R.drawable.clock_7_15_image
    );
    private int[] clockNames = {R.string.quarter_past_one,R.string.half_past_eight
            , R.string.half_past_two,R.string.six_oclock,R.string.quarter_to_eleven
            ,R.string.half_past_twelve,R.string.quarter_past_seven};


    int counter = 0;
    ImageView clockImage;
    TextView nameOfClock;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clock_game);

        clockImage= findViewById(R.id.imageViewClockImage);
        nameOfClock = findViewById(R.id.textViewClock);

        next = findViewById(R.id.buttonNext);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(counter > 5){
                    Intent i = new Intent(ClockGame.this,ClockGameQuiz.class);
                    startActivity(i);
                }

                clockImage.setImageResource(imgList.get(counter));
                nameOfClock.setText(clockNames[counter+1]);
                counter++;

            }
        });
    }
}