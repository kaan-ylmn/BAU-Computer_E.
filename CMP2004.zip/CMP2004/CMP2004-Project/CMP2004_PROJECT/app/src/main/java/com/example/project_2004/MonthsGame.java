package com.example.project_2004;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

public class MonthsGame extends AppCompatActivity {

    private List<Integer> imgList = Arrays.asList(
            R.drawable.spring_image,
            R.drawable.summer_image,
            R.drawable.autum_image
    );
    private int[] monthNames = {R.string.january,R.string.february,R.string.march,R.string.april
            ,R.string.may,R.string.june,R.string.july,R.string.august,R.string.september
            ,R.string.october,R.string.november};
    private int[] monthNumber = {R.string.first,R.string.second,R.string.third
            ,R.string.fourth,R.string.fifth,R.string.sixth,R.string.seventh
            ,R.string.eighth,R.string.ninth,R.string.tenth,R.string.eleventh};


    int counter = 0;
    int seasonCounter = 0;
    ImageView seasonImage;
    TextView numberOfMonth, nameOfMonth;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_months_game);

        seasonImage = findViewById(R.id.imageViewSeasons);
        numberOfMonth = findViewById(R.id.textViewWhichNumberMonth);
        nameOfMonth = findViewById(R.id.textViewNameOfMonth);
        next = findViewById(R.id.buttonNext);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(counter > 10){
                    Intent i = new Intent(MonthsGame.this,MonthGameQuiz.class);
                    startActivity(i);

                }
                
                nameOfMonth.setText(monthNames[counter]);
                numberOfMonth.setText(monthNumber[counter]);
                counter++;

                if(counter % 3 == 0){
                    seasonImage.setImageResource(imgList.get(seasonCounter));
                    seasonCounter++;
                }

            }
        });
    }
}