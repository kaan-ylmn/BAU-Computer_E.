package com.example.project_2004;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class Menu extends AppCompatActivity {

    NavigationView navigationView;
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    LinearLayout clockGame,seasonGame,dayGame,monthGame,multiGame,spellWriteWord
            ,digitGame,digitBackwardGame,directionsGame;


    FirebaseAuth auth = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        clockGame = findViewById(R.id.clockGame);
        seasonGame = findViewById(R.id.seasonGame);
        dayGame = findViewById(R.id.dayOfWeekGame);
        multiGame = findViewById(R.id.multiplicationGame);
        monthGame = findViewById(R.id.monthGame);
        spellWriteWord = findViewById(R.id.spellWriteWord);
        digitGame = findViewById(R.id.digitsGame);
        digitBackwardGame = findViewById(R.id.digitBackwardGame);
        directionsGame = findViewById(R.id.directionsGame);

        drawerLayout = findViewById(R.id.drawerLayout);
        buttonDrawerToggle = findViewById(R.id.buttonMainMenuDrawerToggle);
        navigationView = findViewById(R.id.navigationView);
        navigationView.bringToFront();

        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.open();
            }
        });



        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if(itemId == R.id.mainMenuNavClock){

                    Toast.makeText(Menu.this,"Clock Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,ClockGame.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavSeason){

                    Toast.makeText(Menu.this,"Season Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,SeasonsGame.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavDays){

                    Toast.makeText(Menu.this,"Day Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,DayOfWeekGame.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavMonths){

                    Toast.makeText(Menu.this,"Months Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,MonthsGame.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavDigits){

                    Toast.makeText(Menu.this,"Digit Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,DigitsGame.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavDigitsBackward){

                    Toast.makeText(Menu.this,"Digits Backward Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,DigitsBackwardGame.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavWriteWord){

                    Toast.makeText(Menu.this,"Spell Word Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,SpeelWriteWordGame.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavDirections){

                    Toast.makeText(Menu.this,"Directions Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,DirectionsGame.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavMultiplication){

                    Toast.makeText(Menu.this,"Multiplication Game Clicked",Toast.LENGTH_SHORT).show();

                    Intent i = new Intent(Menu.this,MultiplicationGameQuiz.class);
                    startActivity(i);

                }

                else if(itemId == R.id.mainMenuNavFindPictures){
                    Toast.makeText(Menu.this,"Find Pictures Game Clicked",Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Menu.this,FindPictures.class);
                    startActivity(i);
                }

                else if(itemId == R.id.mainMenuNavBall){
                    Toast.makeText(Menu.this,"Ball Game Clicked",Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Menu.this,BallActivity.class);
                    startActivity(i);
                }

                else if(itemId == R.id.mainMenuNavSignOut){
                    Toast.makeText(Menu.this,"Sign Out Clicked",Toast.LENGTH_SHORT).show();
                    auth.signOut();
                    Intent i = new Intent(Menu.this,MainActivity.class);
                    startActivity(i);
                    finish();
                }

                else if(itemId == R.id.mainMenuNavShare){
                    Toast.makeText(Menu.this,"Share Clicked",Toast.LENGTH_SHORT).show();
                }

                else if(itemId == R.id.mainMenuNavRateUs){
                    Toast.makeText(Menu.this,"Rate Us Clicked",Toast.LENGTH_SHORT).show();
                }

                return false;
            }
        });

        clockGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,ClockGame.class);
                startActivity(i);
            }
        });


        multiGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Menu.this,MultiplicationGameQuiz.class);
                startActivity(i);

            }
        });

        dayGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,DayOfWeekGame.class);
                startActivity(i);
            }
        });

        monthGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,MonthsGame.class);
                startActivity(i);
            }
        });

        seasonGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(Menu.this,SeasonsGame.class);
                startActivity(i);

            }
        });

        spellWriteWord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,SpeelWriteWordGame.class);
                startActivity(i);
            }
        });

        digitGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,DigitsGame.class);
                startActivity(i);
            }
        });

        digitBackwardGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,DigitsBackwardGame.class);
                startActivity(i);
            }
        });

        directionsGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,DirectionsGame.class);
                startActivity(i);
            }
        });

        findViewById(R.id.ballGame).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, BallActivity.class);
                startActivity(intent);

            }
        });

        findViewById(R.id.findPictures).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, FindPictures.class);
                startActivity(intent);
            }
        });


    }
}