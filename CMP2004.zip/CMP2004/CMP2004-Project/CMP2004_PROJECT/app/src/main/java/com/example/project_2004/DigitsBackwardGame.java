package com.example.project_2004;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DigitsBackwardGame extends AppCompatActivity {


    private int [] numbersBackwardShown = {24,21,7,19,8,6,3};

    TextView digitsShown,numbersLeft;
    Button next;

    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_digits_backward_game);

        numbersLeft = findViewById(R.id.textViewBackwardNumbersLeft);
        digitsShown = findViewById(R.id.textViewDigitsBackwardShown);
        next = findViewById(R.id.buttonNext);



        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(counter > 6){
                    Intent i = new Intent(DigitsBackwardGame.this,DigitsBackwardGameQuiz.class);
                    startActivity(i);
                }

                numbersLeft.setText(""+(6-counter));
                digitsShown.setText("" + numbersBackwardShown[counter]);
                counter++;
            }
        });

    }



}