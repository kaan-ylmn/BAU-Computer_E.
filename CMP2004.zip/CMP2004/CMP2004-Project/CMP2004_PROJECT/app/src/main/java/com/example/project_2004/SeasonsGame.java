package com.example.project_2004;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

public class SeasonsGame extends AppCompatActivity {

    private List<Integer> imgList = Arrays.asList(
            R.drawable.spring_image,
            R.drawable.summer_image,
            R.drawable.autum_image
    );

    private int[] seasonNames = {R.string.spring, R.string.summer, R.string.autumn};
    private int imgIdx = 0;


    ImageView seasonsImage;
    TextView sesonsName;
    Button next;

    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seasons_game);

        seasonsImage = findViewById(R.id.imageViewSeasonsImage);
        sesonsName = findViewById(R.id.textViewSeasonsName);
        next = findViewById(R.id.buttonNext);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(counter == imgList.size()){
                    Intent i = new Intent(SeasonsGame.this,SeasonGameQuiz.class);
                    startActivity(i);
                }

                seasonsImage.setImageResource(imgList.get(counter));
                sesonsName.setText(seasonNames[counter]);
                counter++;
            }
        });


    }

}