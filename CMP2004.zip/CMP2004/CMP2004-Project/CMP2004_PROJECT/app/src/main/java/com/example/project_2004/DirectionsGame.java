package com.example.project_2004;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

public class DirectionsGame extends AppCompatActivity {

    private List<Integer> imgList = Arrays.asList(
            R.drawable.behind_table,
            R.drawable.next_to,
            R.drawable.in_the_box,
            R.drawable.under_table
    );

    private int[] seasonNames = {R.string.behind_table,R.string.next_to_table
            ,R.string.in_box,R.string.under_table};
    private int imgIdx = 0;


    ImageView directionsImage;
    TextView directionsName;
    Button next;

    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directions_game);

        directionsImage = findViewById(R.id.imageViewDirectionsImage);
        directionsName = findViewById(R.id.textViewDirectionsName);
        next = findViewById(R.id.buttonNext);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(counter == imgList.size()){
                    Intent i = new Intent(DirectionsGame.this,DirectionsGameQuiz.class);
                    startActivity(i);
                }

                directionsImage.setImageResource(imgList.get(counter));
                directionsName.setText(seasonNames[counter]);
                counter++;
            }
        });


    }

}