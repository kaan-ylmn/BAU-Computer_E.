package com.example.project_2004;
import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class BallActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ball);

        final FrameLayout container = findViewById(R.id.ball_container);

        // Use a ViewTreeObserver to wait until the layout process is complete and the dimensions are available
        container.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                container.getViewTreeObserver().removeOnGlobalLayoutListener(this);

                int ballSize = 100;
                int numberOfBalls = container.getHeight() / ballSize;

                List<BallView> balls = new ArrayList<>();

                for (int i = 0; i < numberOfBalls; i++) {
                    final BallView ballView = new BallView(BallActivity.this);
                    balls.add(ballView);
                }

                startAnimation(balls, container, ballSize, new int[]{0});
            }
        });
    }

    private void startAnimation(List<BallView> balls, FrameLayout container, int ballSize, int[] index) {
        if (index[0] >= balls.size()) {
            index[0] = 0; // Go back to the first ball
        }

        BallView ballView = balls.get(index[0]);
        container.addView(ballView, new ViewGroup.LayoutParams(ballSize, ballSize));
        ballView.setTranslationY(index[0] * ballSize);

        ObjectAnimator animator = ObjectAnimator.ofFloat(ballView, "translationX", 0, container.getWidth() - ballView.getWidth());
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.setRepeatCount(0);
        animator.setDuration(2000); // Set the duration to 2000 milliseconds (2 seconds)

        animator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                container.removeView(ballView); // Remove the ball from the container
                index[0]++; // Increment the index
                startAnimation(balls, container, ballSize, index); // Start the next animation
            }

            @Override
            public void onAnimationCancel(Animator animation) {
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
            }
        });

        animator.start();
    }
}