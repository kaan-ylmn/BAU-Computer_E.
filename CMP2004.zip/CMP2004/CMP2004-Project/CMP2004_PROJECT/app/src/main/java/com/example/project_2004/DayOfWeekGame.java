package com.example.project_2004;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

public class DayOfWeekGame extends AppCompatActivity {

    private List<Integer> imgList = Arrays.asList(
            R.drawable.tuesday,
            R.drawable.wednesday,
            R.drawable.thursday,
            R.drawable.friday,
            R.drawable.saturday,
            R.drawable.sunday
    );

    private int[] dayNames = {R.string.tuesday, R.string.wednesday
            , R.string.thursday, R.string.friday
            , R.string.saturday, R.string.sunday};
    private int[] dayNumber = {R.string.second, R.string.third
            , R.string.fourth, R.string.fifth
            , R.string.sixth, R.string.seventh};
    int counter = 0;
    ImageView daysImage;
    TextView numberOfDay, nameOfDay;
    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_of_week_game);

        daysImage = findViewById(R.id.imageViewDay);
        numberOfDay = findViewById(R.id.textViewWhichNumberMonth);
        nameOfDay = findViewById(R.id.textViewNameOfMonth);
        next = findViewById(R.id.buttonNext);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(counter == 6){
                    Intent i = new Intent(DayOfWeekGame.this,DayOfWeekGameQuiz.class);
                    startActivity(i);
                }

                daysImage.setImageResource(imgList.get(counter));
                nameOfDay.setText(dayNames[counter]);
                numberOfDay.setText(dayNumber[counter]);
                counter++;
            }
        });


    }
}