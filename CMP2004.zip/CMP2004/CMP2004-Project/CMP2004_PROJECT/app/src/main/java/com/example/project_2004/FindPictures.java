package com.example.project_2004;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FindPictures extends AppCompatActivity {

    static class FinalContainer<T> {
        T value;

        FinalContainer(T value) {
            this.value = value;
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture_finder);

        List<Integer> images = new ArrayList<>();
        images.add(R.drawable.camel);
        images.add(R.drawable.coala);
        images.add(R.drawable.fox);
        images.add(R.drawable.lion);
        images.add(R.drawable.monkey);
        images.add(R.drawable.wolf);
        images.add(R.drawable.camel);
        images.add(R.drawable.coala);
        images.add(R.drawable.fox);
        images.add(R.drawable.lion);
        images.add(R.drawable.monkey);
        images.add(R.drawable.wolf);
        Collections.shuffle(images);

        FrameLayout[] buttons = {
                findViewById(R.id.button1_frame), findViewById(R.id.button2_frame), findViewById(R.id.button3_frame),
                findViewById(R.id.button4_frame), findViewById(R.id.button5_frame), findViewById(R.id.button6_frame),
                findViewById(R.id.button7_frame), findViewById(R.id.button8_frame), findViewById(R.id.button9_frame),
                findViewById(R.id.button10_frame), findViewById(R.id.button11_frame), findViewById(R.id.button12_frame)
        };

        int[] buttonImages = new int[12];
        FinalContainer<Integer> matchedPairs = new FinalContainer<>(0);

        int cardBack = R.drawable.code;
        FinalContainer<Integer> clicked = new FinalContainer<>(0);
        FinalContainer<Boolean> turnOver = new FinalContainer<>(false);
        FinalContainer<Integer> lastClicked = new FinalContainer<>(-1);

        boolean[] isFlipped = new boolean[12];

        for (int i = 0; i < 12; i++) {
            int finalI = i;
            buttons[i].setOnClickListener(v -> {
                if (clicked.value < 2) {
                    ImageView imageView = (ImageView) ((FrameLayout) v).getChildAt(0);
                    if (!isFlipped[finalI] && !turnOver.value) {
                        imageView.setImageResource(images.get(finalI));
                        buttonImages[finalI] = images.get(finalI);
                        isFlipped[finalI] = true;
                        if (clicked.value == 0) {
                            lastClicked.value = finalI;
                        }
                        clicked.value++;
                    } else if (isFlipped[finalI]) {
                        imageView.setImageResource(cardBack);
                        isFlipped[finalI] = false;
                        clicked.value--;
                    }
                    if (clicked.value == 2) {
                        turnOver.value = true;
                        if (buttonImages[finalI] == buttonImages[lastClicked.value]) {
                            buttons[finalI].setClickable(false);
                            buttons[lastClicked.value].setClickable(false);
                            turnOver.value = false;
                            clicked.value = 0;
                            matchedPairs.value++;

                            if (matchedPairs.value == 6) {
                                Intent intent = new Intent(FindPictures.this, Menu.class);
                                startActivity(intent);
                            }
                        } else {
                            new Handler().postDelayed(() -> {
                                ImageView imageView1 = (ImageView) ((FrameLayout) buttons[finalI]).getChildAt(0);
                                ImageView imageView2 = (ImageView) ((FrameLayout) buttons[lastClicked.value]).getChildAt(0);
                                imageView1.setImageResource(cardBack);
                                imageView2.setImageResource(cardBack);
                                isFlipped[finalI] = false;
                                isFlipped[lastClicked.value] = false;
                                clicked.value = 0;
                                turnOver.value = false;
                            }, 1000);
                        }
                    }
                }
            });
        }
    }
}