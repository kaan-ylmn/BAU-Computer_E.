package com.example.project_2004;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public class BallView extends View {
    private final Paint paint;

    public BallView(Context context) {
        super(context);
        paint = new Paint();
        paint.setColor(android.graphics.Color.RED);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(getWidth() / 2, getHeight() / 2, Math.min(getWidth(), getHeight()) / 2, paint);
    }
}