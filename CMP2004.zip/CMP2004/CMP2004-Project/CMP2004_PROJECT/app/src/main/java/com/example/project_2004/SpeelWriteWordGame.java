package com.example.project_2004;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;

public class SpeelWriteWordGame extends AppCompatActivity {

    private List<Integer> imgList = Arrays.asList(
            R.drawable.lion_image,
            R.drawable.chocolate_image,
            R.drawable.bird_image,
            R.drawable.apple_image,
            R.drawable.dog_image,
            R.drawable.fish_image,
            R.drawable.octopus_image,
            R.drawable.kite_image,
            R.drawable.rabbit_image,
            R.drawable.cat
    );

    private int[] words= {R.string.lion,R.string.chocolate,R.string.bird
            ,R.string.apple,R.string.dog,R.string.fish,R.string.octopus
            ,R.string.kites,R.string.rabbit,R.string.cat};
    private int[] wordsSpell= {R.string.lion2,R.string.chocolate2,R.string.bird2
            ,R.string.apple2,R.string.dog2,R.string.fish2,R.string.octopus2
            ,R.string.kites2,R.string.rabbit2,R.string.cat2};

    

    ImageView wordImage;
    TextView wordSpell,word;
    Button next;

    int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speel_write_word_game);

        wordImage = findViewById(R.id.imageViewImageOfWord);
        wordSpell= findViewById(R.id.textViewSpellWord);
        word= findViewById(R.id.textViewWord);
        next = findViewById(R.id.buttonNext);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(counter == imgList.size()){
                    Intent i = new Intent(SpeelWriteWordGame.this,SpellWriteWordGameQuiz.class);
                    startActivity(i);
                }

                wordImage.setImageResource(imgList.get(counter));
                word.setText(words[counter]);
                wordSpell.setText(wordsSpell[counter]);
                counter++;
            }
        });


    }

}